import _ from 'lodash';
import React, { Component } from 'react';
import { connect } from 'react-redux';
import ContactForm from './ContactForm';
import { contactUpdate, contactEdit, contactDelete } from '../actions';
import { Card, CardSection, Button } from './common';

class ContactEdit extends Component {
  componentWillMount() {
    _.each(this.props.contact, (value, prop) => {
      this.props.contactUpdate({ prop, value });
    });
  }

  onButtonSavePress() {
    const { id, firstName, lastName, age } = this.props;
    //console.log(firstName, lastName, age);
    this.props.contactEdit({ id, firstName, lastName, age });
  }

  onButtonDeletePress() {
    const { id } = this.props;
    //console.log(firstName, lastName, age);
    this.props.contactDelete({ id });
  }

  render() {
    return (
      <Card>
        <ContactForm />
        <CardSection>
          <Button onPress={this.onButtonSavePress.bind(this)}>
            Save Changes
          </Button>
          <Button onPress={this.onButtonDeletePress.bind(this)}>
            Delete Contact
          </Button>
        </CardSection>
      </Card>
    );
  }
}

const mapStateToProps = (state) => {
  console.log(state);
  const { id, firstName, lastName, age } = state.contactForm;

  return { id, firstName, lastName, age };
};

export default connect(mapStateToProps, { contactUpdate, contactEdit, contactDelete })(ContactEdit);
